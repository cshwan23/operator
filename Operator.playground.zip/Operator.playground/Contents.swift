// 1강 연산자

// 산술 연산자 - 사칙연산 할 때 쓰는 연산자
var weight = 65
weight = weight + 10
weight = weight - 10
weight = weight * 10
weight = weight / 10
weight = weight % 10

weight = 65
weight += 10
weight -= 10
weight *= 10
weight /= 10
weight %= 10

// 비교 연산자
// <, >, ==, !=
let age = 25
let isAdult = age >= 20
let 중1 = age == 14

// 논리 연산자
// &&, ||, !      // &&(and) ||(or) !(not)
    
// 엔드(and) 연산자
// 조건식1 && 조건식2 => 두 가지 조건식 모두 true(참)일 때 결과 true
true && true
// 연산자 우선 순위는 할당 연산자 < 논리연산자 < 비교 연산자
let 초등학생 = ((age >= 8) && (age <= 13))
// 괄호가 없어도 동일한 순서로 연산이 된다.

// 오아(or) 연산자
// 조건식1 || 조건식2 => 두 가지 조건식 중 하나 이상 true일 때 결과 true

// 낫(not) 연산자
// ! => true, false 바꿈
// let 초등학생 = !(age >= 8 && age <= 13)   이러면 결과가 true 에서 false로 바뀜


